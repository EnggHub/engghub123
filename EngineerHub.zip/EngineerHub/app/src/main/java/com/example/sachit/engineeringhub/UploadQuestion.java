package com.example.sachit.engineeringhub;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class UploadQuestion extends AppCompatActivity {
    String name;
    String id;
    Spinner spin1;
    InputStream is = null;
    String result = null;
    String line = null;
    int code;
    View v;
    EditText eid, ename;
    SessionManager session;
    public String receivedValue;
    String Designation,Email;
    public static String spinvalue1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload_question);
        v=(View)findViewById(R.id.questionUpload);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        ename = (EditText) findViewById(R.id.editText2);
        Button insert = (Button) findViewById(R.id.button1);
        // Session class instance
        spin1 = (Spinner) findViewById(R.id.spinner);
        List<String> categories2 = new ArrayList<String>();
        categories2.add("Select...");
        categories2.add("cse");
        categories2.add("it");
        categories2.add("entc");
        categories2.add("me");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories2);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin1.setAdapter(dataAdapter);



        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        Designation = user.get(SessionManager.KEY_DESIG);
        Email = user.get(SessionManager.KEY_EMAIL);


        insert.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //**************Check Network Status*******************************
                String status = NetworkUtil.getConnectivityStatusString(UploadQuestion.this);
                Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
                if(status =="Not connected to Internet")
                {
                    snackbar.setActionTextColor(Color.RED);
                    TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextColor(Color.RED);
                    tv.setTextSize(18);
                    snackbar.show();
                }
                else {
                    name = ename.getText().toString();
                    spinvalue1=spin1.getSelectedItem().toString();
                    if(name.isEmpty())
                    {
                        ename.setError("Enter Question Here....");
                    }
                    else if (spinvalue1.equals("Select..."))
                    {
                        ((TextView)spin1.getSelectedView()).setError("Select Correct");
                    }
                    else {
                        name = name.replaceAll(" ", "%20");
                        //insert();
                        new backgroundProcessClass().execute("");
                    }
                }
            }
        });
    }

    private class backgroundProcessClass extends AsyncTask<String,Void,Void> {
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (receivedValue.contains("1")) {
                ename.setText("");
                //Toast.makeText(getApplicationContext(), "Successfully", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Successfully Uploaded", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
               // Intent i = new Intent(getApplicationContext(),UploadQuestion.class);
              //  startActivity(i);
                //finish();
            } else {
                //Toast.makeText(getApplicationContext(), "Not Uploaded", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Not Uploaded", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            }
            super.onPostExecute(aVoid);
        }


        @Override
        protected Void doInBackground(String... params) {

            HttpClient client = new DefaultHttpClient();
            HttpPost post = new HttpPost(Weburl.url2 + "/Questionupload.php");

            List<NameValuePair> pairs = new ArrayList<NameValuePair>(1);
            pairs.add(new BasicNameValuePair("name", name));
           // pairs.add(new BasicNameValuePair("Designation", Designation));
            pairs.add(new BasicNameValuePair("Email", Email));
            pairs.add(new BasicNameValuePair("branch", spinvalue1));
            Log.d("check",""+name+Email+spinvalue1);

            try {
                post.setEntity(new UrlEncodedFormEntity(pairs));
            }
            catch (Exception ex) {
                Log.e("Iamhrer","lll");
            }
            try {
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                receivedValue = client.execute(post, responseHandler);
                Log.d("rece",""+receivedValue);

            } catch (Exception ex) {
                Log.e("kay be","ho kay karat");
            }


            return null;
        }


    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id =item.getItemId();
        if (id == android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
