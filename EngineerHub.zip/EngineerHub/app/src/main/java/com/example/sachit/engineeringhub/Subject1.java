package com.example.sachit.engineeringhub;


public class Subject1 {
	public String id;
	public String date;
    public String Subject_Name;
    public String Subject_Full_Form;
    public static String question;
   // public static int questionpos;
    public static int quesid;
    public static String text;
    
}