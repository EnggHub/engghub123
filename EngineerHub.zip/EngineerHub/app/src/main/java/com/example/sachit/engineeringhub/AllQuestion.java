package com.example.sachit.engineeringhub;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.design.widget.Snackbar;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AllQuestion extends AppCompatActivity {

    ListView AllQuestionListView;
    ProgressBar progressBar;
    //String question;
    InputStream is=null;
    String result=null;
    String line=null;
    View v;
    SessionManager session;
    String dept;
    public String Dept1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        setContentView(R.layout.activity_all_question);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        v=(View)findViewById(R.id.activity_main);
        AllQuestionListView = (ListView) findViewById(R.id.AllQuestionListView);
        //Intent i2=getIntent();
        //dept=i2.getStringExtra("did");


        session = new SessionManager(getApplicationContext());
        HashMap<String, String> user = session.getUserDetails();
        Dept1= user.get(SessionManager.KEY_DEPT_ID);
        Log.d("dept",""+Dept1);
        //Toast.makeText(getApplicationContext(), "dep"+Dept1,Toast.LENGTH_SHORT).show();
        //**************Check Network Status*******************************
        String status = NetworkUtil.getConnectivityStatusString(AllQuestion.this);
        Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
        if(status =="Not connected to Internet")
        {
            snackbar.setActionTextColor(Color.RED);
            TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
            tv.setTextColor(Color.RED);
            tv.setTextSize(18);
            snackbar.show();
        }
        else {


            progressBar = (ProgressBar) findViewById(R.id.ProgressBar1);

            new ParseJSonDataClass(this).execute();

        }
        AllQuestionListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick (AdapterView<?> parent, View view, int position, long id) {
                //**************Check Network Status*******************************
                String status = NetworkUtil.getConnectivityStatusString(AllQuestion.this);
                Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
                if (status == "Not connected to Internet") {
                    snackbar.setActionTextColor(Color.RED);
                    TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                    tv.setTextColor(Color.RED);
                    tv.setTextSize(18);
                    snackbar.show();
                } else {
                    TextView textView = (TextView) view.findViewById(R.id.SubjectNameTextView);
                    Subject1.text = textView.getText().toString();
                    //Subject.text=Subject.replaceAll(" ", "%20");
                    Toast.makeText(getApplicationContext(), Subject1.text, Toast.LENGTH_LONG).show();
                    ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    position = position + 1;
                    String b = String.valueOf(position);
                    nameValuePairs.add(new BasicNameValuePair("id", Subject1.text));

                    try {
                        //String link= "http://anticipated-part.000webhostapp.com/insert.php?id='"+id+"'&name='"+name+"'";
                        HttpClient httpclient = new DefaultHttpClient();
                        HttpPost httppost = new HttpPost(Weburl.url2 + "/QuestionCheck.php?");
                        httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                        HttpResponse response = httpclient.execute(httppost);
                        HttpEntity entity = response.getEntity();
                        is = entity.getContent();
                        Log.e("pass 1", "connection success ");

                        // Toast.makeText(getApplicationContext(), "con",
                        //4000).show();


                    } catch (Exception e) {
                        Log.e("Fail 1", e.toString());
                        Toast.makeText(AllQuestion.this, e.toString(),
                                Toast.LENGTH_LONG).show();
                        Toast.makeText(getApplicationContext(), "Invalid IP Address",
                                Toast.LENGTH_LONG).show();
                    }

                    try {
                        BufferedReader reader = new BufferedReader
                                (new InputStreamReader(is, "iso-8859-1"), 8);
                        StringBuilder sb = new StringBuilder();
                        while ((line = reader.readLine()) != null) {
                            sb.append(line + "\n");
                        }
                        is.close();
                        result = sb.toString();
                        Log.e("pass 2", "connection success ");
                        Intent i = new Intent(AllQuestion.this, Forum.class);
                        startActivity(i);
                        //=result;
                        Subject1.question = result;
                        Toast.makeText(getApplicationContext(), "please wait", Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Log.e("Fail 2", e.toString());
                    }

                }
            }
        });


    }

    //*************************
    private class ParseJSonDataClass extends AsyncTask<Void, Void, Void> {
        public Context context;
        String FinalJSonResult;
        List<Subject> SubjectFullFormList;

        public ParseJSonDataClass(Context context) {

            this.context = context;
        }

        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0) {

            String HttpURL = Weburl.url2+"/QuestionFetch.php?did="+Dept1;
            HttpServiceClass httpServiceClass = new HttpServiceClass(HttpURL);
           // Log.d("dept",""+Dept1);
            //List<NameValuePair> pairs = new ArrayList<NameValuePair>(1);
            //pairs.add(new BasicNameValuePair("did", dept));
           // Local.did=Local.did2;


            try {
                httpServiceClass.ExecutePostRequest();

                if (httpServiceClass.getResponseCode() == 200) {

                    FinalJSonResult = httpServiceClass.getResponse();

                    if (FinalJSonResult != null) {

                        JSONArray jsonArray = null;
                        try {

                            jsonArray = new JSONArray(FinalJSonResult);
                            JSONObject jsonObject;
                            Subject subject;

                            SubjectFullFormList = new ArrayList<Subject>();

                            for (int i = 0; i < jsonArray.length(); i++) {

                                subject = new Subject();

                                jsonObject = jsonArray.getJSONObject(i);

                                subject.Subject_Name = jsonObject.getString("id");
                                // Toast.makeText(context, subject.Subject_Name, Toast.LENGTH_SHORT).show();
                                subject.Subject_Full_Form = jsonObject.getString("Question");

                                SubjectFullFormList.add(subject);
                            }
                        } catch (JSONException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                } else {

                    //Toast.makeText(context, httpServiceClass.getErrorMessage(), Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)

        {
            progressBar.setVisibility(View.GONE);

            AllQuestionListView.setVisibility(View.VISIBLE);

            if (SubjectFullFormList != null) {

                ListAdapter adapter = new ListAdapter(SubjectFullFormList, context);

                AllQuestionListView.setAdapter(adapter);



            }
        }
    }
    //****************For Back press menu*******************
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id =item.getItemId();
        if (id == android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

}
