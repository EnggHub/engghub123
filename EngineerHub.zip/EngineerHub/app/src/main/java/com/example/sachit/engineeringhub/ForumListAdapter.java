package com.example.sachit.engineeringhub;




import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class ForumListAdapter extends BaseAdapter
{
    Context context;

    List<Subject1> subject_list;

    public ForumListAdapter(List<Subject1> listValue, Context context)
    {
        this.context = context;
        this.subject_list = listValue;
    }

    @Override
    public int getCount()
    {
        return this.subject_list.size();
    }

    @Override
    public Object getItem(int position)
    {
        return this.subject_list.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        ViewItem1 viewItem = null;
        if(convertView == null)
        {
            viewItem = new ViewItem1();

            LayoutInflater layoutInfiater = (LayoutInflater)this.context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInfiater.inflate(R.layout.listview_items2, null);
            viewItem.subid= (TextView)convertView.findViewById(R.id.subid);
            viewItem.SubNameTextView = (TextView)convertView.findViewById(R.id.SubjectNameTextView);
            viewItem.date= (TextView)convertView.findViewById(R.id.date);
            viewItem.SubFullFormTextView = (TextView)convertView.findViewById(R.id.SubjectFullFormTextView);
            convertView.setTag(viewItem);
        }
        else
        {
            viewItem = (ViewItem1) convertView.getTag();
        }
        viewItem.subid.setText(subject_list.get(position).id);
        viewItem.date.setText(subject_list.get(position).date);

        viewItem.SubNameTextView.setText(subject_list.get(position).Subject_Name);

        viewItem.SubFullFormTextView.setText(subject_list.get(position).Subject_Full_Form);

        return convertView;
    }
}

class ViewItem1
{
    public TextView subid;
    TextView date;
	TextView SubNameTextView;
    TextView SubFullFormTextView;
}
