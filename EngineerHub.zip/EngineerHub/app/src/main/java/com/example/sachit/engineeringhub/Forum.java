package com.example.sachit.engineeringhub;



import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static android.graphics.Paint.ANTI_ALIAS_FLAG;


public class Forum extends AppCompatActivity {

	 ListView SubjectFullFormListView;
	    ProgressBar progressBar;
	    TextView ques;
	    //Button ans;
	    EditText anstext;
	    String answer;
		FloatingActionButton AnsPost;
	    InputStream is=null;
	    String result=null;
		String line=null;
		View v;
	SessionManager session;
	public String receivedValue;
	String Designation,Email;
		
	    String HttpURL;

	    @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.forum);
	        SubjectFullFormListView = (ListView) findViewById(R.id.SubjectFullFormListView);
	        progressBar = (ProgressBar) findViewById(R.id.ProgressBar1);
	        ques=(TextView) findViewById(R.id.question);
	        //ans=(Button) findViewById(R.id.button1);
	        anstext=(EditText) findViewById(R.id.answer);
	        v=(View)findViewById(R.id.activity_main);
			getSupportActionBar().setDisplayHomeAsUpEnabled(true);
	        AnsPost=(FloatingActionButton)findViewById(R.id.QuestionAnswer);
	        View v=(View)findViewById(R.id.activity_main);
	        AnsPost.setImageBitmap(textAsBitmap("Post", 60, Color.WHITE));
			session = new SessionManager(getApplicationContext());
			HashMap<String, String> user = session.getUserDetails();
			Designation = user.get(SessionManager.KEY_DESIG);
			Email = user.get(SessionManager.KEY_EMAIL);

	        new ParseJSonDataClass(this).execute();

	       ques.setText(Subject1.question);

	     AnsPost.setOnClickListener(new View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
					//**************Check Network Status*******************************
					String status = NetworkUtil.getConnectivityStatusString(Forum.this);
					Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
					if(status =="Not connected to Internet")
					{
						snackbar.setActionTextColor(Color.RED);
						TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
						tv.setTextColor(Color.RED);
						tv.setTextSize(18);
						snackbar.show();
					}
					else {
						answer = anstext.getText().toString();
						if(answer.isEmpty())
						{
							anstext.setError("Enter Your Answer......");
						}
						else {
							//answer = answer.replaceAll(" ", "%20");
							//insert();
							new backgroundProcessClass().execute("");
						}
					}
				}
			});
	    }
		 
		    public void insert()
		    {
		    	try
		    	{
		    		String lnk=Weburl.url2+"/insertanswer.php?id='"+Subject1.text+"'&ans='"+answer+"'";
		    		//String link= "http://anticipated-part.000webhostapp.com/insert.php?id='"+id+"'&name='"+name+"'";
				    HttpClient httpclient = new DefaultHttpClient();
			        HttpPost httppost = new HttpPost(lnk);

					HttpResponse response = httpclient.execute(httppost);
			        HttpEntity entity = response.getEntity();
			        is = entity.getContent();
			        Log.e("pass 1", "connection success ");
			        Toast.makeText(getApplicationContext(), "posted successfully",
							Toast.LENGTH_LONG).show();
			        anstext.setText("");


			        new ParseJSonDataClass(this).execute();
			        
			}
		        catch(Exception e)
			{
		        	Log.e("Fail 1", e.toString());
		        	Toast.makeText(Forum.this, e.toString(),
		    				Toast.LENGTH_LONG).show();
			    	Toast.makeText(getApplicationContext(), "Invalid IP Address1",
					Toast.LENGTH_LONG).show();
			}     
		        
		        try
		        {
		            BufferedReader reader = new BufferedReader
					(new InputStreamReader(is,"iso-8859-1"),8);
		            StringBuilder sb = new StringBuilder();
		            while ((line = reader.readLine()) != null)
			    {
		                sb.append(line + "\n");
		            }
		            is.close();
		            result = sb.toString();
			    Log.e("pass 2", "connection success ");
			   // Toast.makeText(getApplicationContext(), result,Toast.LENGTH_LONG).show();
			}
		        catch(Exception e)
			{
		            Log.e("Fail 2", e.toString());
			}     

	        
	    }

	private class backgroundProcessClass extends AsyncTask<String,Void,Void> {
		protected void onPreExecute() {
			super.onPreExecute();
		}

		@Override
		protected void onPostExecute(Void aVoid) {
			if (receivedValue.contains("1")) {
				//Toast.makeText(getApplicationContext(), "Successfully", Toast.LENGTH_SHORT).show();
				Snackbar snackbar = Snackbar.make(v, "Successfully Uploaded", Snackbar.LENGTH_LONG);
				snackbar.setActionTextColor(Color.RED);
				TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
				tv.setTextColor(Color.RED);
				tv.setTextSize(18);
				snackbar.show();
				anstext.setText(" ");
				//SubjectFullFormListView.notifyDataSetChanged();
				//Intent i = new Intent(getApplicationContext(),HomeActivity.class);
				//startActivity(i);
				//finish();

			} else {
				//Toast.makeText(getApplicationContext(), "Not Uploaded", Toast.LENGTH_SHORT).show();
				Snackbar snackbar = Snackbar.make(v, "Not Uploaded", Snackbar.LENGTH_LONG);
				snackbar.setActionTextColor(Color.RED);
				TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
				tv.setTextColor(Color.RED);
				tv.setTextSize(18);
				snackbar.show();
			}
			super.onPostExecute(aVoid);
		}


		@Override
		protected Void doInBackground(String... params) {

			HttpClient client = new DefaultHttpClient();
			HttpPost post = new HttpPost(Weburl.url2 + "/insertanswer.php");

			List<NameValuePair> pairs = new ArrayList<NameValuePair>(1);
			pairs.add(new BasicNameValuePair("id", Subject1.text));
			pairs.add(new BasicNameValuePair("ans", answer));
			pairs.add(new BasicNameValuePair("Designation", Designation));
			pairs.add(new BasicNameValuePair("Email", Email));

			try {
				post.setEntity(new UrlEncodedFormEntity(pairs));
			}
			catch (Exception ex) {
				Log.e("Iamhrer","lll");
			}
			try {
				ResponseHandler<String> responseHandler = new BasicResponseHandler();
				receivedValue = client.execute(post, responseHandler);
				Log.d("rece",""+receivedValue);

			} catch (Exception ex) {
				Log.e("kay be","ho kay karat");
			}


			return null;
		}


	}

	    private class ParseJSonDataClass extends AsyncTask<Void, Void, Void> {
	        public Context context;
	        String FinalJSonResult;
	        List<Subject1> SubjectFullFormList;

	        public ParseJSonDataClass(Context context) {

	            this.context = context;
	        }

	        @Override
	        protected void onPreExecute() {

	            super.onPreExecute();
	        }

	        @Override
	        protected Void doInBackground(Void... arg0) {
              HttpURL= Weburl.url2+"/AnswerFetch.php?id="+Subject1.text;
	            HttpServiceClass httpServiceClass = new HttpServiceClass(HttpURL);

	            try {
	                httpServiceClass.ExecutePostRequest();

	                if (httpServiceClass.getResponseCode() == 200) {

	                    FinalJSonResult = httpServiceClass.getResponse();

	                    if (FinalJSonResult != null) {

	                        JSONArray jsonArray = null;
	                        try {

	                            jsonArray = new JSONArray(FinalJSonResult);
	                            JSONObject jsonObject;
	                            Subject1 subject;

	                            SubjectFullFormList = new ArrayList<Subject1>();

	                            for (int i = 0; i < jsonArray.length(); i++) {

	                                subject = new Subject1();

	                                jsonObject = jsonArray.getJSONObject(i);

	                                subject.Subject_Name = jsonObject.getString("postby");
	                               // Toast.makeText(context, subject.Subject_Name, Toast.LENGTH_SHORT).show();
	                                subject.Subject_Full_Form = jsonObject.getString("answer");
	                                subject.id = jsonObject.getString("time");
	                                subject.date= jsonObject.getString("date");

	                                SubjectFullFormList.add(subject);
	                            }
	                        } catch (JSONException e) {
	                            // TODO Auto-generated catch block
	                            e.printStackTrace();
	                        }
	                    }
	                } else {

	                    Toast.makeText(context, httpServiceClass.getErrorMessage(), Toast.LENGTH_SHORT).show();
	                }
	            } catch (Exception e) {
	                // TODO Auto-generated catch block
	                e.printStackTrace();
	            }
	            return null;
	        }

	        @Override
	        protected void onPostExecute(Void result)

	        {
	            progressBar.setVisibility(View.GONE);

	            SubjectFullFormListView.setVisibility(View.VISIBLE);

	            if (SubjectFullFormList != null) {

	                ForumListAdapter adapter = new ForumListAdapter(SubjectFullFormList, context);

	                SubjectFullFormListView.setAdapter(adapter);
	            }
	        }
	    }



	public static Bitmap textAsBitmap(String text, float textSize, int textColor) {
		Paint paint = new Paint(ANTI_ALIAS_FLAG);
		paint.setTextSize(textSize);
		paint.setColor(textColor);
		paint.setTextAlign(Paint.Align.LEFT);
		float baseline = -paint.ascent(); // ascent() is negative
		int width = (int) (paint.measureText(text) + 0.0f); // round
		int height = (int) (baseline + paint.descent() + 0.0f);
		Bitmap image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);

		Canvas canvas = new Canvas(image);
		canvas.drawText(text, 0, baseline, paint);
		return image;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		int id =item.getItemId();
		if (id == android.R.id.home)
		{
			this.finish();
		}
		return super.onOptionsItemSelected(item);
	}
}

