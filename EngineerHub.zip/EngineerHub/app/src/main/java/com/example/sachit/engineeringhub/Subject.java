package com.example.sachit.engineeringhub;

public class  Subject {
    public String id;
    public String Subject_Name;
    public String Subject_Full_Form;

}
