package com.example.sachit.engineeringhub;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


public class Startup extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);
        ActionBar ab = getActionBar();
//        ab.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#123456")));
        Thread t=new Thread(new LoginThread());
        t.start();
    }
    class LoginThread implements Runnable {
        @Override
        public void run() {
            // TODO Auto-generated method stub
            try
            {
                Thread.sleep(2000);
            }
            catch(Exception ex)
            {

            }
            Intent i = new Intent(getApplicationContext(),Login.class);
            startActivity(i);
        }




    }
}
