package com.example.sachit.engineeringhub;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.StrictMode;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class Login extends AppCompatActivity {
    Button b1,b2;
    EditText ed1,ed2;
    Spinner spin;
    public static String e1,e2;
    public static String spinvalue,emailPattern;
    private ProgressDialog progress;
    final Context context = this;
    View v;
    public static String receivedValue = "";
    SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        b1 = (Button) findViewById(R.id.button);
        b2 = (Button) findViewById(R.id.button1);
        ed1 = (EditText) findViewById(R.id.editText);
        ed2 = (EditText) findViewById(R.id.editText3);
        // Session Manager
        session = new SessionManager(getApplicationContext());

        spin = (Spinner) findViewById(R.id.spinner);
        List<String> categories = new ArrayList<String>();
        categories.add("Select...");
        categories.add("Student");
        categories.add("Staff");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(dataAdapter);

        spin.getSelectedItem().toString();
        emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

       // Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();
        final boolean login_status = session.isLoggedIn();

        if (login_status == true)
        {
            Intent i = new Intent(getApplicationContext(),Navigation.class);
            startActivity(i);
            finish();
        }
        else {
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    e1 = ed1.getText().toString();
                    e2 = ed2.getText().toString();
                    spinvalue = spin.getSelectedItem().toString();

                    if (e1.equals(""))
                    {
                        ed1.setError("Enter Email Adderss Here..");
                    }
                    else if(!e1.matches(emailPattern))
                    {
                        ed1.setError("Invalid Email Id");
                    }
                    else if (e2.equals(""))
                    {
                        ed2.setError("Ente Password Here..");
                    }
                    else if (spinvalue.equals("Select..."))
                    {
                        ((TextView)spin.getSelectedView()).setError("Select Correct");
                    }
                    else {
                        try {
                            progress = new ProgressDialog(context);
                            progress.setMessage("Wait...");
                            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            progress.setIndeterminate(false);
                            progress.setProgress(0);
                            progress.setCancelable(false);
                            progress.show();
                            new backgroundProcessClass().execute("");
                        } catch (Exception ex) {
                            Toast.makeText(context, "Error=" + ex.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });
        }
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Toast.makeText(getApplicationContext(),"ok wait...",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),Register.class);
                startActivity(i);
            }
        });
    }
    private class backgroundProcessClass extends AsyncTask<String, Void, Void> {
        @Override
        protected void onPreExecute() {

            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            String s=receivedValue;
            String[] parts = s.split(",");
            String post = parts[0];
            String prof_id = parts[1];
            Local.did= parts[2];
            //Local.did2=parts[2];
            String prof_id1 =parts[2];
            if (post.contains("Staff")) {
                Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                session.createLoginSession(e1,spinvalue,prof_id,prof_id1);
                Intent i = new Intent(Login.this,Navigation.class);
                startActivity(i);
            }else if (post.contains("Student")) {
                Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                session.createLoginSession(e1,spinvalue,prof_id,prof_id1);
                Log.d("id",""+e1+spinvalue+prof_id+prof_id1);
                Intent i = new Intent(Login.this,Navigation.class);
                startActivity(i);
            }else if (post.contains("Admin")) {
                Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                session.createLoginSession(e1,"Admin",prof_id,prof_id1);

                Intent i = new Intent(Login.this,Navigation.class);
                startActivity(i);
            }

            else {
                //Toast.makeText(context, "Invalid Authentication", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Invalid Authentication", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            }
            progress.dismiss();
            super.onPostExecute(aVoid);
        }

        @Override
        protected Void doInBackground(String... params) {

            HttpClient client = new DefaultHttpClient();
            HttpPost post = new HttpPost(Weburl.url + "/lg.php");
            //temp=params[0];
            List<NameValuePair> pairs = new ArrayList<NameValuePair>(1);
            pairs.add(new BasicNameValuePair("e1", e1));
            pairs.add(new BasicNameValuePair("e2", e2));
            pairs.add(new BasicNameValuePair("e3", spinvalue));

            try {
                post.setEntity(new UrlEncodedFormEntity(pairs));
            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(), "Error 1=" + ex.toString(), Toast.LENGTH_SHORT).show();

            }
            //Perform HTTP Request
            try {
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                receivedValue = client.execute(post, responseHandler);
                // Toast.makeText(getApplicationContext(), receivedValue, Toast.LENGTH_SHORT).show();
                //name.setText(receivedValue);
            } catch (Exception ex) {
                Toast.makeText(getApplicationContext(), "Error 2=" + ex.toString(), Toast.LENGTH_SHORT).show();
            }
            return null;
        }
    }

}


