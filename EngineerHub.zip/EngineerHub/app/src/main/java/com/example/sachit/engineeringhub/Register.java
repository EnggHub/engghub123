package com.example.sachit.engineeringhub;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

public class Register extends AppCompatActivity {
    EditText name,Mname,Lname,mobile,email,pwd,cpwd,roll,Branch;
    Button update;
    Integer integer1,integer2,integer3;
    public static String sname,sMname,sLname,smobile,semail,sBranch,sDivision,spwd,scpwd,sroll,emailPattern,year;

    Spinner spinner1,spinner2,spinnerdiv;

    private ProgressDialog progress;
    final Context context=this;
    public static String receivedValue="";
    View v;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        v=(View)findViewById(R.id.register);
        name=(EditText)findViewById(R.id.firstName) ;
        Mname=(EditText)findViewById(R.id.middleName) ;
        Lname=(EditText)findViewById(R.id.lastNmae) ;
        mobile=(EditText)findViewById(R.id.editText2) ;
        email=(EditText)findViewById(R.id.editText3) ;
       // Branch=(EditText)findViewById(R.id.branch);
        pwd=(EditText)findViewById(R.id.editText4) ;
        cpwd=(EditText)findViewById(R.id.editText5) ;
        roll=(EditText)findViewById(R.id.editText7) ;
        update=(Button)findViewById(R.id.button4);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        spinner1 =(Spinner)findViewById(R.id.spinner1);
        spinner2 =(Spinner)findViewById(R.id.spinner2);
        spinnerdiv =(Spinner)findViewById(R.id.spinnerDiv);


        List<String> categories=new ArrayList<String>();
        categories.add("Year");
        categories.add("FE");
        categories.add("SE");
        categories.add("TE");
        categories.add("BE");

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, categories);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        List<String> SelectBranch=new ArrayList<String>();
        SelectBranch.add("Branch");
        SelectBranch.add("cse");
        SelectBranch.add("it");
        SelectBranch.add("entc");
        SelectBranch.add("me");


        ArrayAdapter<String> dataAdapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, SelectBranch);

        dataAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ///*********************************Division dropdown*************************
        List<String> Division=new ArrayList<String>();
        Division.add("Division");
        Division.add("DIV-A");
        Division.add("DIV-B");
        Division.add("DIV-C");
        Division.add("DIV-d");
        ArrayAdapter<String> dataAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, Division);

        dataAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner1.setAdapter(dataAdapter);
        spinner2.setAdapter(dataAdapter1);
        spinnerdiv.setAdapter(dataAdapter2);
        emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sname=name.getText().toString();
                sMname=Mname.getText().toString();
                sLname=Lname.getText().toString();
                smobile=mobile.getText().toString();
                semail=email.getText().toString();
                sroll=roll.getText().toString();
                sBranch=spinner2.getSelectedItem().toString();
                sDivision=spinnerdiv.getSelectedItem().toString();
                spwd=pwd.getText().toString();
                scpwd=cpwd.getText().toString();
               year=spinner1.getSelectedItem().toString();

                if(sroll.equals(""))
                {
                    roll.setError("Enter Roll");
                }
                else if(sname.equals(""))
                {
                    name.setError("Enter name");
                }
                else if(smobile.equals(""))
                {
                    mobile.setError("Enter Mobile Number");
                }
                else if(smobile.length()!=10)
                {
                    mobile.setError("Enter 10 digits");
                }
                else if(semail.equals(""))
                {
                    email.setError("Enter Email");
                }
                else if (sBranch.equals("Branch"))
                {
                    ((TextView)spinner2.getSelectedView()).setError("Select Correct Branch");

                }
                else if (year.equals("Year"))
                {
                    ((TextView)spinner1.getSelectedView()).setError("Select Correct Year");

                    //Toast.makeText(getApplicationContext(),"Please Select Year",Toast.LENGTH_SHORT).show();
                }
                else if (sDivision.equals("Division"))
                {
                    ((TextView)spinnerdiv.getSelectedView()).setError("Select Correct Division");
                }

                else if(!semail.matches(emailPattern))
                {
                    email.setError("Invalid Email Id");
                }
                else if(spwd.equals(""))
                {
                    pwd.setError("Enter Password");
                }
                else if(scpwd.equals(""))
                {
                    cpwd.setError("Enter Confirm Password");
                }
                else if(spwd.equals(scpwd))
                {

                    try {
                        progress=new ProgressDialog(context);
                        progress.setMessage("Wait...");
                        progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                        progress.setIndeterminate(false);
                        progress.setProgress(0);
                        progress.setCancelable(false);
                        progress.show();
                        new backgroundProcessClass().execute("");
                    }
                    catch (Exception ex)
                    {
                        Toast.makeText(context, "Error="+ex.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
                else
                {
                    cpwd.setError("Incorrect Confirm Password");
                }
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id =item.getItemId();
        if (id == android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }


    private class backgroundProcessClass extends AsyncTask<String,Void,Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            if (receivedValue.contains("1")) {
               // Toast.makeText(getApplicationContext(), "Email Already Exists", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Pleased Login With Proper Id..", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            } else if (receivedValue.contains("2")) {
                //Toast.makeText(getApplicationContext(), "Mobile Already Exists", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Mobile Already Exists.", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            } else if (receivedValue.contains("3")) {
                //Toast.makeText(getApplicationContext(), "Roll Already Exists", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Roll Already Exists...", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            } else if (receivedValue.contains("success")) {
                Toast.makeText(getApplicationContext(), "Registered Successfully", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(getApplicationContext(),Login.class);
                startActivity(i);
                finish();
            } else {
               // Toast.makeText(context, "Not Registered", Toast.LENGTH_SHORT).show();
                Snackbar snackbar = Snackbar.make(v, "Something Wrong Not Register...", Snackbar.LENGTH_LONG);
                snackbar.setActionTextColor(Color.RED);
                TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
                tv.setTextColor(Color.RED);
                tv.setTextSize(18);
                snackbar.show();
            }
            progress.dismiss();

            super.onPostExecute(aVoid);
        }

        @Override
        protected Void doInBackground(String... params) {


            HttpClient client = new DefaultHttpClient();
            HttpPost post = new HttpPost(Weburl.url + "/user-register.php");
            //temp=params[0];
            List<NameValuePair> pairs = new ArrayList<NameValuePair>(1);
            pairs.add(new BasicNameValuePair("e1", sroll));
            pairs.add(new BasicNameValuePair("e2", sname));
            pairs.add(new BasicNameValuePair("e7", sMname));
            pairs.add(new BasicNameValuePair("e8", sLname));
            pairs.add(new BasicNameValuePair("e3", smobile));
            pairs.add(new BasicNameValuePair("e4", semail));
            pairs.add(new BasicNameValuePair("e5", spwd));
            pairs.add(new BasicNameValuePair("e6", year));
            pairs.add(new BasicNameValuePair("e9",sBranch));
            pairs.add(new BasicNameValuePair("e10",sDivision));

            try {
                post.setEntity(new UrlEncodedFormEntity(pairs));
            } catch (Exception ex) {
                Log.e("I am here","lll");
                //  Toast.makeText(getApplicationContext(), "Error 1="+ex.toString(), Toast.LENGTH_SHORT).show();
            }
            //Perform HTTP Request
            try {
                ResponseHandler<String> responseHandler = new BasicResponseHandler();
                receivedValue = client.execute(post, responseHandler);
                // Toast.makeText(getApplicationContext(), receivedValue, Toast.LENGTH_SHORT).show();

                //name.setText(receivedValue);
            } catch (Exception ex) {
                Log.e("I am here","aaaa");

                // Toast.makeText(getApplicationContext(), "Error 2="+ex.toString(), Toast.LENGTH_SHORT).show();
            }


            return null;
        }
    }
}
