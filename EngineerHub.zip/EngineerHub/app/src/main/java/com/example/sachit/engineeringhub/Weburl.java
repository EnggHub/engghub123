package com.example.sachit.engineeringhub;

public class Weburl{
        public static String url="https://engghub.000webhostapp.com";
        public static String url2="https://engghub.000webhostapp.com";
        Weburl()
        {

        }
}
