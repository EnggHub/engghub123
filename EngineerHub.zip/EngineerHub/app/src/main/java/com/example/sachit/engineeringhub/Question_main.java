package com.example.sachit.engineeringhub;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Question_main extends AppCompatActivity {
	
	
	Button b1,b2;
	View v;
	
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.question_main);
        v=(View)findViewById(R.id.questionMain);
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setDisplayShowHomeEnabled(true);
         
        Button b1=(Button) findViewById(R.id.button1);
        Button b2=(Button) findViewById(R.id.button2);
		//**************Check Network Status*******************************
		String status = NetworkUtil.getConnectivityStatusString(Question_main.this);
		Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
		if(status =="Not connected to Internet")
		{
			snackbar.setActionTextColor(Color.RED);
			TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
			tv.setTextColor(Color.RED);
			tv.setTextSize(18);
			snackbar.show();
		}
		else {
		}
        b2.setOnClickListener(new View.OnClickListener() {
			
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			//**************Check Network Status*******************************
			String status = NetworkUtil.getConnectivityStatusString(Question_main.this);
			Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
			if(status =="Not connected to Internet")
			{
				snackbar.setActionTextColor(Color.RED);
				TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
				tv.setTextColor(Color.RED);
				tv.setTextSize(18);
				snackbar.show();
			}
			else {
				Intent i = new Intent(Question_main.this, ListMain.class);
				startActivity(i);
			}
			
		
		}
	});
        b1.setOnClickListener(new View.OnClickListener() {
			
    		@Override
    		public void onClick(View v) {
    			// TODO Auto-generated method stub
				//**************Check Network Status*******************************
				String status = NetworkUtil.getConnectivityStatusString(Question_main.this);
				Snackbar snackbar = Snackbar.make(v, status, Snackbar.LENGTH_LONG);
				if(status =="Not connected to Internet")
				{
					snackbar.setActionTextColor(Color.RED);
					TextView tv = (TextView) snackbar.getView().findViewById(android.support.design.R.id.snackbar_text);
					tv.setTextColor(Color.RED);
					tv.setTextSize(18);
					snackbar.show();
				}
				else {

					Intent i = new Intent(Question_main.this, Department_ques.class);
					startActivity(i);
				}
    			
    		
    		}
    	});
        
        		
        		
    }

    //****************For Back press menu*******************
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		int id =item.getItemId();
		if (id == android.R.id.home)
		{
			this.finish();
		}
		return super.onOptionsItemSelected(item);
	}

}
