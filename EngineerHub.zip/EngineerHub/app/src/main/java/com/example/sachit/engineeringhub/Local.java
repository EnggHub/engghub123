package com.example.sachit.engineeringhub;

public class Local {
	 public static String getstatus="";
	public static String did;
	//public static String did2;
	static String url ;   //="http://anticipated-part.000webhostapp.com/list.php?table='"+Local.getstatus+"'";
	 }
