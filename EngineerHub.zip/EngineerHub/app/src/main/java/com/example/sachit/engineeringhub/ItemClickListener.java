package com.example.sachit.engineeringhub;

import android.view.View;

/**
 * Created by Akshay on 09/12/2017.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
