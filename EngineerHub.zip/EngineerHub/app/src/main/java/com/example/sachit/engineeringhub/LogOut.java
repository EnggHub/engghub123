package com.example.sachit.engineeringhub;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

public class LogOut extends AppCompatActivity {
    SessionManager session;
    //public static String Designation,E_mail;
    //Button btnLogout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_out);

        // Session class instance
        session = new SessionManager(getApplicationContext());

        TextView lblName = (TextView) findViewById(R.id.lblName);
        TextView lblmageid = (TextView) findViewById(R.id.lblmageid);
        TextView lblEmail = (TextView) findViewById(R.id.lblEmail);

        // Button logout
        //btnLogout = (Button) findViewById(R.id.btnLogout);

        //Toast.makeText(getApplicationContext(), "User Login Status: " + session.isLoggedIn(), Toast.LENGTH_LONG).show();

        session.checkLogin();
        HashMap<String, String> user = session.getUserDetails();
        String email = user.get(SessionManager.KEY_EMAIL);
        String designation = user.get(SessionManager.KEY_DESIG);
        String desig = user.get(SessionManager.KEY_PROF_ID);
        // displaying user data
        lblEmail.setText(Html.fromHtml("Email: <b>" + email + "</b>"));
        lblName.setText(Html.fromHtml("Designation: <b>" + designation + "</b>"));
        lblmageid.setText(Html.fromHtml("Image Id: <b>" + desig + "</b>"));


    }
    @Override
    protected void onStart()
    {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this,R.style.MyDialogTheme);

        // Setting Dialog Title
        alertDialog.setTitle("LogOut...");

        // Setting Dialog Message
        alertDialog.setMessage("Are you sure you want to Logout?\n");

        // Setting Icon to Dialog
        alertDialog.setIcon(R.drawable.dept);

        // Setting Positive "Yes" Button
        alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "You clicked on YES", Toast.LENGTH_SHORT).show();
                session.logoutUser();
            }
        });
        alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // Write your code here to invoke NO event
                Toast.makeText(getApplicationContext(), "You clicked on NO", Toast.LENGTH_SHORT).show();
                dialog.cancel();
                Intent i = new Intent(getApplicationContext(),Navigation.class);
                startActivity(i);
                finish();
            }
        });

        // Showing Alert Message
        alertDialog.show();
        super.onStart();
    }
}
